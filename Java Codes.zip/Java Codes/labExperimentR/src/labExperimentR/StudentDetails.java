package labExperimentR;

public class StudentDetails {
	String name;
	long rollNo;
	int marks[] = new int[5];	
	
	StudentDetails()
	{
		name = "";
		rollNo = 0;
		
	}
	
	void display()
	{
		System.out.println("Student name : "+name);
		System.out.println("Roll No : "+rollNo);
		System.out.println("Marks in ASA, DAA, OOP, SEPM, IAI: ");
		for (int j = 0; j<5; j++)
		{
			System.out.println(marks[j]);
		}
	}
}

