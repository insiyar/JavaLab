package labExperimentR;

import java.util.Scanner;

public class Details { 

public static void main(String args[]) {
	
	Scanner sc = new Scanner (System.in);
	System.out.println("Enter the number of students to be added.");
	int n = sc.nextInt();
	
	//creating array of objects.
	StudentDetails obj[] = new StudentDetails[n];
	
	
	
	// input details
	for(int i = 0; i < n; i ++)
	{
		
		obj[i] = new StudentDetails();
		System.out.println("Enter student name: ");
		obj[i].name = sc.next();
		System.out.println("Enter student Roll No: ");
		obj[i].rollNo = sc.nextLong();
		System.out.println("Enter marks in ASA, DAA, OOP, SEPM, IAI: ");
		for (int j = 0; j<5; j++)
		{
			
			obj[i].marks[j] = sc.nextInt();
		}
	}
	
	
	
	System.out.println("Displaying Details: ");
	for(int i = 0; i < n; i ++)
	{
		System.out.println("Student "+i+1+" : "+obj[i].name);
		System.out.println("Roll No : "+obj[i].rollNo);
		System.out.println("Marks in ASA, DAA, OOP, SEPM, IAI: ");
		for (int j = 0; j<5; j++)
		{
			System.out.println(obj[i].marks[j]);
		}
	}	
	
	sc.close();
			
}
}