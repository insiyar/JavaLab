package labExperimentR;
import java.io.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BufferedDetails {

	public static void main(String args[]) throws IOException {
	
		//File fobj = new File ("myfile.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the number of students to be added.");
		int n = Integer.parseInt(br.readLine());
		
		//creating array of objects.
		StudentDetails obj[] = new StudentDetails[n];
		
		/*String name[] = new String [n];
		//int m[] = new int [n];
		//long roll[] = new long [n];
		*/
		
		
		
		// input details
		for(int i = 0; i < n; i ++)
		{
			
			obj[i] = new StudentDetails();
			System.out.println("Enter student name: ");
			obj[i].name = br.readLine();
			System.out.println("Enter student Roll No: ");
			obj[i].rollNo = Long.parseLong(br.readLine());
			System.out.println("Enter marks in ASA, DAA, OOP, SEPM, IAI: ");
			
			for (int j = 0; j<5; j++)
			{
				System.out.println("enter:");
				obj[i].marks[j] = Integer.parseInt(br.readLine());
				
			}
		}
		
		
		
		
		System.out.println("Displaying Details: ");
		for(int i = 0; i < n; i ++)
		{
			System.out.println("Student "+i+" : "+obj[i].name);
			System.out.println("Roll No : "+obj[i].rollNo);
			System.out.println("Marks in ASA, DAA, OOP, SEPM, IAI: ");
			for (int j = 0; j<5; j++)
			{
				System.out.println(obj[i].marks[j]);
			}
		}	
				
	}
	}

