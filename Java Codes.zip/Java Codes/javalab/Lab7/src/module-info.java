/**
 * 
 */
/**
 * @author insiyarizvi
 *
 */
module Lab7 {
}