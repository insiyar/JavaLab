public class Demo1
{
	public static void main(String args[])
	{ 		
		System.out.println("Hello World");
		System.out.println("Array Length: "args.length);
		String fName = args[0];
		String lName = args[1];
		System.out.println(fName);
		System.out.println(lName);
	}
}

