/* 
Write a Java Program to accept 10 numbers in an array and compute the square of each number.
Print the sum of these numbers.
*/
import java.util.*;
import java.io.*;
public class SumOfSquares {
    public static void main(String args[]) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter 10 numbers:");
        int arr[]= new int[10];
        int brr[] = new int[10];
        int sum=0;
        for(int i=0;i<10;i++)
        {
            System.out.println(i+1+":");
            arr[i] = sc.nextInt(); 
            brr[i] = arr[i]*arr[i];
            sum += brr[i];
        }
        System.out.println("Sum of Squares of the numbers: "+sum);
        sc.close();
    }
    
}
