public class TerminalCalc
{
	public static void main(String args[])
	{
		int a = Integer.parseInt(args[0]);
		String op = args[1];
		int b = Integer.parseInt(args[2]);
		if (op.equals("+"))
		{
			System.out.println(a+b);
		}
		else if (op.equals("-"))
		{
					System.out.println(a-b);
		}
		else if(op.equals("x"))
		{
			System.out.println(a*b);	
		}
		else if(op.equals("/"))
		{
			System.out.println(a/b);
		}
		else
		{
			System.out.println("Operator not identified");
		}
	}	
}