class Marks{
public static void main(String args[]){
	int marks[] = new int [10];
	for (int i = 0; i<10; i++){
		marks[i] =Integer.parseInt(args[i]);
	}
	for (int i=0; i<9; i++){
		for (int j=0; j<9-i-1; j++){
		if (marks[j]>marks[j+1]){
			int t = marks[j];
			marks[j] = marks[j+1];
			marks[j+1] = t;
		}
		}
	}
	for (int i=0; i<10; i++){	
		if (marks[i]<40)
			System.out.println(marks[i]+": Fail");
		else if (marks[i]>=40 && marks[i]<=50)
			System.out.println(marks[i]+": Pass");
		else if (marks[i]>=51 && marks[i]<=75)
                        System.out.println(marks[i]+": Merit");
		else if (marks[i]>75)
			System.out.println(marks[i]+": Distinction");
		else 
			System.out.println("Invalid marks entered");
	}
}
}
