package com.aiml;

import java.util.*;

/*Write a program to accept three digits (i.e. 0 - 9) and print all its possible combinations.
(For example if the three digits are 1, 2, 3 than all possible combinations are : 123, 132,
213, 231, 312, 321.)*/

public class NumCom3 
{
	public static void main(String args[]) 
	{
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter 3 digits. 0-9 ");
		int num[] = new int [3];
		for (int i=0; i<3; i++)
		{
			num[i] = sc.nextInt();
		}
		for (int i=0; i<3; i++)
		{
			for (int j=0; j<3; j++)
			{
				for (int k = 0; k<3; k++)
				{
					int sum = num[i]*100+num[j]*10+num[k];
					System.out.println(sum);
				}
				
			}
		}
		sc.close();
		
	}
}


