/**
 * 
 */
/**
 * @author insiyarizvi
 *
 */
module Lab4 {
}