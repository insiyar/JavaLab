package com.aiml;

import java.util.Scanner;

/*
 * Initialise respective array variables for 10 students. 
 * Handle ArrayIndexOutOfBoundsExeption, so that any such problem doesn’t cause illegal termination of program.
 */
public class Lab7Exp1 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String stu_names[] = new String [10];
		int stu_marks[] = new int[10];
		try {
			for (int i=0; i<10; i++)
			{
				System.out.println("Enter name of student and their marks:");
				stu_names[i] = sc.next();
				stu_marks[i] = sc.nextInt();
			}
			for (int i=0; i<10; i++)
			{
				System.out.println(stu_names);
			}
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Trying to access an index not present in array.");
		}
		
		
		
	}
	
}
