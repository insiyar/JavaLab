package com.aiml;

public class Prog1 {
	public static void main(String args[]) {
		
	}

}
